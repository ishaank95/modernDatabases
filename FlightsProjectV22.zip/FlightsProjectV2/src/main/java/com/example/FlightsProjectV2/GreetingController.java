package com.example.FlightsProjectV2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.*;
import java.util.ArrayList;
import java.util.List;


@Controller
public class GreetingController {
	Flight yoyo;
	List<Flight> flights = new ArrayList<>();
	@Autowired
	private FlightRepository repository;
	@GetMapping("/insertFlight")
	public String greetingForm(Model model) {
		model.addAttribute("flight", new Flight());
		return "insertFlight";
	}

	@PostMapping("/insertFlight")
	public String greetingSubmit(@ModelAttribute Flight flight) {
		flights.add(flight);


		repository.insert(flight);
		repository.save(flight);

		//repoTest.findFlightByAirline(flight.airlineCode);

		return "result";
	}
	@GetMapping("/searchFlight")
	public String searchForm(Model model) {
		model.addAttribute("flight", new Flight());
		return "searchFlight";
	}
	@PostMapping("/searchFlight")
	public String flightSubmit(@ModelAttribute Flight flight) {



		repository.delete(flight);
		//repoTest.findFlightByAirline(flight.airlineCode);

		return "searchFlight";
	}

	@GetMapping("/realSearch")
	public String searchFormReal(Model model) {
		model.addAttribute("flight", new Flight());
		return "realSearch";
	}

	@PostMapping("/realSearch")
	public String searchin(@ModelAttribute Flight flight, Model model) {

		flight=repository.findByairlineCode(flight.airlineCode);
		model.addAttribute("flight",flight);
		System.out.println(flight.source);
		return "resultV2";
	}



}
