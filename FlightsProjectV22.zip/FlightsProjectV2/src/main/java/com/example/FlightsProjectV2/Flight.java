package com.example.FlightsProjectV2;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.FieldType;
import org.springframework.data.mongodb.core.mapping.MongoId;

@Document ("Flights")
public class Flight {

    @MongoId(value = FieldType.OBJECT_ID)
    public String id;

    public int year;
    public int month;
    public int date;
    public String airlineCode;
    public String flightCode;
    public String source;
    public String destination;
    public String time;
    public int delay;

    public int getYear() {
        return year;
    }
    public String getId () {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }


    public void setYear(int year) {
        this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }
    public int getDate() {
        return date;
    }

    public void setDate(int date) {
        this.date = date;
    }

    public String getAirlineCode() {
        return airlineCode;
    }

    public void setAirlineCode(String airlineCode) {
        this.airlineCode = airlineCode;
    }
    public String getFlightCode() {
        return flightCode;
    }

    public void setFlightCode(String FlightCode) {
        this.flightCode = flightCode;
    }
    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }
    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }
    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getDelay() {
        return delay;
    }

    public void setDelay(int delay) {
        this.delay = delay;
    }


    @Override
    public String toString() {
        return String.format(
                "Flight[source=%s, destination='%s', delay='%s']",
                source, destination, delay);
    }

}