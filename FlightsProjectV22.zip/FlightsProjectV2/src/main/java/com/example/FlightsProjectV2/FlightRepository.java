package com.example.FlightsProjectV2;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface FlightRepository extends MongoRepository<Flight, String> {


    public Flight findByairlineCode(String airlineCode);

}