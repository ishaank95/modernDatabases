package com.example.FlightsProjectV2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightsProjectV2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
